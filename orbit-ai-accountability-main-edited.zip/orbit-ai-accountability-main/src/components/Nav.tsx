import { motion, AnimatePresence } from 'framer-motion';
import { Home, ListTodo, CalendarClock, Target, Repeat, Activity, Sparkles } from 'lucide-react';

export type PageId = 'home' | 'tasks' | 'scheduler' | 'accountability' | 'habits' | 'confidence';

export const NAV: { id: PageId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'tasks', label: 'Plan My Day', icon: ListTodo },
  { id: 'scheduler', label: 'Scheduler', icon: CalendarClock },
  { id: 'accountability', label: 'Accountability', icon: Target },
  { id: 'habits', label: 'Habits', icon: Repeat },
  { id: 'confidence', label: 'Success', icon: Activity },
];

export function Sidebar({ page, setPage }: { page: PageId; setPage: (p: PageId) => void }) {
  return (
    <aside className="hidden w-64 shrink-0 border-r border-white/40 bg-white/40 backdrop-blur-xl lg:flex lg:flex-col">
      <div className="flex items-center gap-3 px-6 py-6">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-sky-400 shadow-lg shadow-blue-500/30">
          <Sparkles className="h-6 w-6 text-white" />
        </div>
        <div>
          <div className="text-lg font-bold leading-tight text-slate-800">Orbit AI</div>
          <div className="text-[10px] text-slate-500">Your Day. Intelligently Orchestrated.</div>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-2">
        {NAV.map((item) => {
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? 'text-blue-700' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {active && (
                <motion.div
                  layoutId="navActive"
                  className="absolute inset-0 rounded-xl bg-blue-50/80 ring-1 ring-blue-200/70"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                />
              )}
              <item.icon className="relative z-10 h-5 w-5" />
              <span className="relative z-10">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="m-3 rounded-2xl glass-blue p-4">
        <div className="text-sm font-semibold">Today's streak</div>
        <div className="mt-1 text-2xl font-bold">5 days</div>
        <div className="mt-1 text-xs text-white/80">Keep it going!</div>
      </div>
      <div className="px-6 pb-4 text-center text-[10px] text-slate-400">Powered by Orbit Intelligence</div>
    </aside>
  );
}

export function MobileNav({ page, setPage }: { page: PageId; setPage: (p: PageId) => void }) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 lg:hidden">
      <div className="glass-strong mx-3 mb-3 flex items-center justify-around rounded-2xl px-2 py-2">
        {NAV.map((item) => {
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`flex flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-medium transition-colors ${
                active ? 'text-blue-700' : 'text-slate-500'
              }`}
            >
              <item.icon className={`h-5 w-5 ${active ? 'scale-110' : ''} transition-transform`} />
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function PageTransition({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={id}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
