import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Check, Shield, Brain, Clock, Sun, CloudRain, Target } from 'lucide-react';
import { ConfidenceRing } from '@/components/ui';

const steps = [
  { text: 'Analyzing schedule...', icon: Clock },
  { text: 'Learning your habits...', icon: Brain },
  { text: 'Checking recurring tasks...', icon: Target },
  { text: 'Understanding your energy...', icon: Sun },
  { text: 'Predicting interruptions...', icon: CloudRain },
  { text: 'Finding the optimal schedule...', icon: Sparkles },
  { text: 'Protecting your priorities...', icon: Shield },
];

const successItems = [
  { label: 'Primary Goal Protected', icon: Shield },
  { label: 'High Focus Work Scheduled', icon: Brain },
  { label: 'Recurring Tasks Managed', icon: Target },
  { label: 'Unexpected Events Prepared', icon: CloudRain },
];

export function OptimizeOverlay({ show, onComplete, successProbability }: { show: boolean; onComplete: () => void; successProbability: number }) {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!show) { setStep(0); setDone(false); return; }
    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      if (i >= steps.length) {
        clearInterval(interval);
        setDone(true);
        setTimeout(onComplete, 2200);
      } else {
        setStep(i);
      }
    }, 850);
    return () => clearInterval(interval);
  }, [show, onComplete]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/60 backdrop-blur-md">
          <motion.div initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.92, y: 20 }} className="glass-strong w-full max-w-md rounded-3xl p-8 text-center">
            {/* Orb */}
            <div className="mb-6 flex justify-center">
              <motion.div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-blue-600 to-sky-400 shadow-lg shadow-blue-500/40" animate={{ scale: [1, 1.08, 1] }} transition={{ repeat: Infinity, duration: 2 }}>
                {done ? <Check className="h-10 w-10 text-white" /> : (
                  <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.8, ease: 'linear' }}>
                    <Sparkles className="h-9 w-9 text-white" />
                  </motion.div>
                )}
                {!done && [0, 1, 2, 3, 4].map((i) => (
                  <motion.span key={i} className="absolute h-1.5 w-1.5 rounded-full bg-white/70" animate={{ x: [0, Math.cos((i * 2 * Math.PI) / 5) * 30], y: [0, Math.sin((i * 2 * Math.PI) / 5) * 30], opacity: [0.8, 0] }} transition={{ repeat: Infinity, duration: 1.6, delay: i * 0.3, ease: 'easeOut' }} />
                ))}
              </motion.div>
            </div>

            {done ? (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                <h2 className="text-xl font-bold text-slate-800">Orbit has planned your day.</h2>
                <p className="mt-1 text-sm text-slate-500">Everything is in place.</p>
                <div className="mt-5 flex flex-col items-center">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Today's AI Success Prediction</p>
                  <ConfidenceRing value={successProbability} size={140} label="Predicted" />
                </div>
                <div className="mt-5 grid grid-cols-2 gap-2 text-left">
                  {successItems.map((item, i) => (
                    <motion.div key={item.label} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.1 }} className="flex items-center gap-2 rounded-xl bg-white/50 p-2.5">
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-100"><item.icon className="h-4 w-4 text-emerald-600" /></div>
                      <span className="text-[11px] font-medium text-slate-700">{item.label}</span>
                    </motion.div>
                  ))}
                </div>
                <button onClick={onComplete} className="mt-5 w-full rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.02]">
                  Start My Day
                </button>
              </motion.div>
            ) : (
              <>
                <h2 className="text-lg font-bold text-slate-800">Optimizing your day...</h2>
                <p className="mt-1 text-sm text-slate-500">Orbit is rebuilding your schedule.</p>
                <div className="mt-6 space-y-2.5 text-left">
                  {steps.map((s, i) => (
                    <motion.div key={s.text} initial={{ opacity: 0.3 }} animate={{ opacity: i < step ? 1 : i === step ? 1 : 0.3 }} className="flex items-center gap-2.5 text-sm">
                      {i < step ? (
                        <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100"><Check className="h-3.5 w-3.5 text-emerald-600" /></div>
                      ) : i === step ? (
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }} className="h-5 w-5 rounded-full border-2 border-blue-500 border-t-transparent" />
                      ) : (
                        <div className="h-5 w-5 rounded-full border-2 border-slate-200" />
                      )}
                      <span className={i <= step ? 'text-slate-700' : 'text-slate-400'}>{s.text}</span>
                    </motion.div>
                  ))}
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
