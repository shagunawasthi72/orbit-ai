import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle, X } from 'lucide-react';

interface WhyButtonProps {
  why: string;
  factors?: { label: string; weight: number }[];
}

export function WhyButton({ why, factors }: WhyButtonProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1 rounded-lg bg-white/70 px-2 py-1 text-[11px] font-semibold text-blue-600 transition hover:bg-white hover:shadow-sm"
      >
        <HelpCircle className="h-3 w-3" /> Why?
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.92, y: 16 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 16 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong w-full max-w-md rounded-3xl p-6"
            >
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400">
                    <HelpCircle className="h-4 w-4 text-white" />
                  </div>
                  <h3 className="text-base font-bold text-slate-800">Why this decision?</h3>
                </div>
                <button onClick={() => setOpen(false)} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>

              <p className="mb-4 text-sm leading-relaxed text-slate-600">{why}</p>

              {factors && factors.length > 0 && (
                <div>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Decision Factors</div>
                  <div className="space-y-2">
                    {factors.map((f, i) => (
                      <div key={f.label}>
                        <div className="mb-0.5 flex justify-between text-[11px]">
                          <span className="text-slate-600">{f.label}</span>
                          <span className="font-semibold text-slate-700">{f.weight}%</span>
                        </div>
                        <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${f.weight}%` }}
                            transition={{ delay: 0.1 + i * 0.06, duration: 0.6, ease: 'easeOut' }}
                            className="h-full rounded-full bg-gradient-to-r from-blue-500 to-sky-400"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button onClick={() => setOpen(false)} className="mt-5 w-full rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-2.5 text-sm font-semibold text-white">
                Got it
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
