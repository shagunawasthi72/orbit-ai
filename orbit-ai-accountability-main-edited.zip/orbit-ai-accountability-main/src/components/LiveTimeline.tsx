import { motion } from 'framer-motion';
import { AlertTriangle, HelpCircle, ArrowRight, TrendingUp, Sparkles } from 'lucide-react';
import type { TimelineEvent } from '@/store';

const kindIcon = {
  detect: AlertTriangle,
  ask: HelpCircle,
  move: ArrowRight,
  predict: TrendingUp,
};

const kindColor = {
  detect: 'bg-amber-100 text-amber-600',
  ask: 'bg-violet-100 text-violet-600',
  move: 'bg-blue-100 text-blue-600',
  predict: 'bg-emerald-100 text-emerald-600',
};

export function LiveTimeline({ events }: { events: TimelineEvent[] }) {
  return (
    <div className="relative pl-2">
      <div className="absolute left-[18px] top-2 bottom-2 w-px bg-gradient-to-b from-blue-200 via-blue-100 to-transparent" />
      <div className="space-y-4">
        {events.map((e, i) => {
          const Icon = kindIcon[e.kind];
          return (
            <motion.div
              key={e.id}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.15, type: 'spring', stiffness: 260, damping: 22 }}
              className="relative flex items-start gap-3"
            >
              <div className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${kindColor[e.kind]} ring-4 ring-white/60`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 rounded-2xl border border-white/50 bg-white/40 p-3">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-400">{e.time}</span>
                  <span className={`text-sm font-bold ${e.kind === 'predict' ? 'text-emerald-600' : 'text-slate-800'}`}>
                    {e.kind === 'predict' && <Sparkles className="mr-1 inline h-3.5 w-3.5" />}
                    {e.label}
                  </span>
                </div>
                <div className="mt-1.5 space-y-1">
                  <div className="flex gap-1.5 text-[11px]">
                    <span className="font-semibold text-slate-400">Reason:</span>
                    <span className="text-slate-600">{e.reason}</span>
                  </div>
                  <div className="flex gap-1.5 text-[11px]">
                    <span className="font-semibold text-blue-500">Decision:</span>
                    <span className="text-slate-600">{e.decision}</span>
                  </div>
                  <div className="flex gap-1.5 text-[11px]">
                    <span className="font-semibold text-emerald-600">Result:</span>
                    <span className={`text-slate-600 ${e.kind === 'predict' ? 'font-bold text-emerald-600' : ''}`}>{e.result}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
