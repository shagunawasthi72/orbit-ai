import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, X, Send, Car, Home, Zap, Stethoscope, User, BookOpen, Bot } from 'lucide-react';
import { LiveDot } from '@/components/ui';

interface Msg {
  id: string;
  from: 'ai' | 'user';
  text: string;
  buttons?: { label: string; value: string }[];
}

const suggestions = [
  { label: "I'm stuck in traffic", icon: Car, value: 'traffic' },
  { label: "I'm tired", icon: Bot, value: 'tired' },
  { label: 'Family work came up', icon: Home, value: 'family' },
  { label: 'Power cut', icon: Zap, value: 'power' },
  { label: 'Medical emergency', icon: Stethoscope, value: 'medical' },
  { label: 'Meeting extended', icon: User, value: 'meeting' },
  { label: "I can't focus", icon: BookOpen, value: 'distracted' },
];

const tooltips = ['Monitoring...', 'Learning...', 'Predicting...', 'Optimizing...', 'Protecting...'];

const flows: Record<string, () => Msg[]> = {
  tired: () => [
    { id: 'r1', from: 'ai', text: "I've noticed today has become more demanding than expected. Your energy is lower than your average. Would you like me to postpone low-priority tasks and keep only essential work?", buttons: [{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }] },
  ],
  traffic: () => [
    { id: 'r1', from: 'ai', text: "I've already detected the traffic and updated your schedule. Study moved to 7:00 PM. Gym shortened to 20 minutes. Your important work remains protected. AI Success Prediction restored to 89%." },
  ],
  meeting: () => [
    { id: 'r1', from: 'ai', text: "Your meeting is taking longer than expected. Don't worry — I've already found the best possible adjustment. Would you still like to complete today's study session?", buttons: [{ label: 'Yes', value: 'yes' }, { label: 'Reschedule', value: 'reschedule' }] },
  ],
  distracted: () => [
    { id: 'r1', from: 'ai', text: "I can see your focus has been drifting this afternoon. That's completely normal. Would you like a 5-minute reset before your next task? It often restores focus by 40%.", buttons: [{ label: 'Yes, reset', value: 'yes' }, { label: 'Not now', value: 'no' }] },
  ],
  family: () => [
    { id: 'r1', from: 'ai', text: "Family comes first — always. I've protected your evening so you can be fully present. Would you like me to move tonight's study session to tomorrow morning when your focus is sharpest?", buttons: [{ label: 'Yes', value: 'yes' }, { label: 'Keep tonight', value: 'no' }] },
  ],
  power: () => [
    { id: 'r1', from: 'ai', text: "Power cut detected. I've moved all device-dependent tasks to tomorrow morning when power is usually restored. Your reading session stays — it needs no power. Your day is still on track." },
  ],
  medical: () => [
    { id: 'r1', from: 'ai', text: "Health comes first — always. I've paused all non-critical tasks for today and kept only your medicine reminder active. Take care of yourself. I'll rebuild the rest of your day tomorrow when you're ready." },
  ],
};

const rescheduleFlow: Msg[] = [
  { id: 'rs1', from: 'ai', text: 'Of course. When would you like me to move it?', buttons: [{ label: 'After this meeting', value: 'after' }, { label: 'Tomorrow', value: 'tomorrow' }, { label: 'Choose Date', value: 'date' }] },
  { id: 'rs2', from: 'ai', text: 'Done. Your schedule has been optimized. Your important work remains protected.' },
];

export function AIOrb() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { id: 'm0', from: 'ai', text: "I'm already monitoring your schedule. Tell me what's happening." },
  ]);
  const [thinking, setThinking] = useState(false);
  const [tooltipIdx, setTooltipIdx] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, thinking]);

  useEffect(() => {
    const t = setTimeout(() => setShowTooltip(true), 1500);
    const t2 = setTimeout(() => setShowTooltip(false), 7000);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, []);

  useEffect(() => {
    if (!showTooltip || open) return;
    const interval = setInterval(() => {
      setTooltipIdx((i) => (i + 1) % tooltips.length);
    }, 2200);
    return () => clearInterval(interval);
  }, [showTooltip, open]);

  function pushMsgs(msgs: Msg[]) {
    setThinking(true);
    setTimeout(() => {
      setThinking(false);
      setMessages((prev) => [...prev, ...msgs]);
    }, 1100);
  }

  function handleSuggestion(value: string) {
    const label = suggestions.find((s) => s.value === value)?.label ?? value;
    const userMsg: Msg = { id: `u${Date.now()}`, from: 'user', text: label };
    setMessages((prev) => [...prev, userMsg]);
    pushMsgs(flows[value]?.() ?? []);
  }

  function handleButton(value: string) {
    const labelMap: Record<string, string> = { yes: 'Yes', no: 'No', reschedule: 'Reschedule', after: 'After this meeting', tomorrow: 'Tomorrow', date: 'Choose Date' };
    const userMsg: Msg = { id: `u${Date.now()}`, from: 'user', text: labelMap[value] ?? value };
    setMessages((prev) => [...prev, userMsg]);

    if (value === 'reschedule') { pushMsgs([rescheduleFlow[0]]); return; }
    if (['after', 'tomorrow', 'date'].includes(value)) { pushMsgs([rescheduleFlow[1]]); return; }
    if (value === 'yes') {
      pushMsgs([{ id: `a${Date.now()}`, from: 'ai', text: "Done. I've adjusted your schedule so you can focus on what matters most. Your important work remains protected." }]);
    } else if (value === 'no') {
      pushMsgs([{ id: `a${Date.now()}`, from: 'ai', text: "No problem at all. I'll keep things as they are. I'm right here if anything changes." }]);
    }
  }

  function handleSend() {
    if (!input.trim()) return;
    const userMsg: Msg = { id: `u${Date.now()}`, from: 'user', text: input.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    pushMsgs([{ id: `a${Date.now()}`, from: 'ai', text: "I've got it. I'm factoring that into today's plan and adjusting as needed. Your day is in good hands." }]);
  }

  return (
    <>
      {/* Floating Orb */}
      <div className="fixed bottom-24 right-5 z-40 lg:bottom-6 lg:right-6">
        <AnimatePresence>
          {showTooltip && !open && (
            <motion.div
              initial={{ opacity: 0, x: 10, y: 10 }}
              animate={{ opacity: 1, x: 0, y: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="glass-strong absolute bottom-16 right-0 w-52 rounded-2xl p-3"
            >
              <div className="flex items-center gap-2 text-xs">
                <LiveDot />
                <span className="font-medium text-slate-700">
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={tooltipIdx}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -4 }}
                      transition={{ duration: 0.3 }}
                      className="inline-block"
                    >
                      {tooltips[tooltipIdx]}
                    </motion.span>
                  </AnimatePresence>
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={() => setOpen((v) => !v)}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
          className="relative flex h-14 w-14 items-center justify-center rounded-full"
          aria-label="Open Orbit AI"
        >
          {/* Outer glow */}
          <motion.div
            className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500 to-sky-400 opacity-40 blur-xl"
            animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.15, 1] }}
            transition={{ repeat: Infinity, duration: 3 }}
          />
          {/* Breathing orb */}
          <motion.div
            className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-blue-600 via-blue-500 to-sky-400 shadow-lg shadow-blue-500/40"
            animate={{ scale: [1, 1.06, 1] }}
            transition={{ repeat: Infinity, duration: 2.4, ease: 'easeInOut' }}
          >
            <Sparkles className="h-6 w-6 text-white" />
            {/* Orbiting particles */}
            {[0, 1, 2, 3].map((i) => (
              <motion.span
                key={i}
                className="absolute h-1 w-1 rounded-full bg-white/80"
                animate={{
                  x: [0, Math.cos((i * Math.PI) / 2) * 22],
                  y: [0, Math.sin((i * Math.PI) / 2) * 22],
                  opacity: [0.8, 0],
                  scale: [1, 0.3],
                }}
                transition={{ repeat: Infinity, duration: 2, delay: i * 0.5, ease: 'easeOut' }}
              />
            ))}
          </motion.div>
        </motion.button>
      </div>

      {/* Assistant Panel */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop for premium expand feel */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-40 bg-slate-900/10 backdrop-blur-[2px] lg:hidden"
            />
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 320, damping: 28 }}
              className="glass-strong fixed bottom-44 right-3 z-50 flex h-[28rem] w-[calc(100vw-1.5rem)] max-w-sm flex-col overflow-hidden rounded-3xl shadow-2xl sm:right-5 lg:bottom-24 lg:right-6"
            >
              {/* Header */}
              <div className="flex items-center justify-between bg-gradient-to-r from-blue-600 to-sky-500 p-4 text-white">
                <div className="flex items-center gap-2">
                  <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 2 }} className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                    <Sparkles className="h-4 w-4" />
                  </motion.div>
                  <div>
                    <div className="text-sm font-bold">Orbit AI</div>
                    <div className="flex items-center gap-1 text-[10px] text-white/80">
                      <LiveDot /> Monitoring your day
                    </div>
                  </div>
                </div>
                <button onClick={() => setOpen(false)} className="rounded-lg p-1 text-white/80 hover:bg-white/20">
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Messages */}
              <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto p-4">
                {messages.map((m) => (
                  <motion.div
                    key={m.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${m.from === 'user' ? 'bg-gradient-to-r from-blue-600 to-sky-500 text-white' : 'glass-soft text-slate-700'}`}>
                      <p>{m.text}</p>
                      {m.buttons && (
                        <div className="mt-2 flex flex-wrap gap-2">
                          {m.buttons.map((b) => (
                            <button key={b.value} onClick={() => handleButton(b.value)} className="rounded-lg bg-white/70 px-3 py-1.5 text-xs font-semibold text-blue-600 transition hover:bg-white">
                              {b.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}

                {/* Thinking indicator */}
                <AnimatePresence>
                  {thinking && (
                    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex justify-start">
                      <div className="glass-soft flex items-center gap-2 rounded-2xl px-3.5 py-3">
                        {[0, 1, 2].map((i) => (
                          <motion.span key={i} className="h-2 w-2 rounded-full bg-blue-400" animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 0.9, delay: i * 0.15 }} />
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Quick suggestions */}
              {messages.length <= 1 && (
                <div className="border-t border-white/40 px-3 py-2">
                  <div className="mb-1.5 text-[10px] font-medium uppercase tracking-wider text-slate-400">Quick Actions</div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {suggestions.map((s) => (
                      <button key={s.value} onClick={() => handleSuggestion(s.value)} className="flex items-center gap-1.5 rounded-lg bg-white/50 px-2 py-1.5 text-left text-[11px] font-medium text-slate-600 transition hover:bg-white/80">
                        <s.icon className="h-3.5 w-3.5 text-blue-500" /> {s.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="flex items-center gap-2 border-t border-white/40 p-3">
                <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Tell Orbit what's happening..." className="flex-1 rounded-xl border border-white/60 bg-white/60 px-3 py-2 text-sm text-slate-800 placeholder-slate-400 outline-none focus:border-blue-300" />
                <button onClick={handleSend} className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 text-white transition hover:scale-105">
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
