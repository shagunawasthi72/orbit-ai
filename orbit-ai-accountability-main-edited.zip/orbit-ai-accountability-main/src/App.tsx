import { useState } from 'react';
import { StoreProvider } from '@/store';
import { Sidebar, MobileNav, PageTransition, type PageId } from '@/components/Nav';
import { AIOrb } from '@/components/AIOrb';
import HomePage from '@/pages/HomePage';
import AddTaskPage from '@/pages/AddTaskPage';
import SchedulerPage from '@/pages/SchedulerPage';
import AccountabilityPage from '@/pages/AccountabilityPage';
import HabitsPage from '@/pages/HabitsPage';
import ConfidencePage from '@/pages/ConfidencePage';

function Shell() {
  const [page, setPage] = useState<PageId>('home');

  return (
    <div className="flex min-h-screen">
      <Sidebar page={page} setPage={setPage} />
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobile top bar */}
        <header className="flex items-center justify-between px-5 py-4 lg:hidden">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2l2.4 5.4L20 8l-4 4 1 6-5-3-5 3 1-6-4-4 5.6-.6L12 2z" strokeLinejoin="round" />
              </svg>
            </div>
            <span className="text-base font-bold text-slate-800">Orbit AI</span>
          </div>
        </header>

        <main className="flex-1 px-4 pb-28 pt-2 sm:px-6 lg:px-10 lg:pb-10 lg:pt-8">
          <div className="mx-auto max-w-6xl">
            <PageTransition id={page}>
              {page === 'home' && <HomePage setPage={setPage} />}
              {page === 'tasks' && <AddTaskPage setPage={setPage} />}
              {page === 'scheduler' && <SchedulerPage />}
              {page === 'accountability' && <AccountabilityPage />}
              {page === 'habits' && <HabitsPage />}
              {page === 'confidence' && <ConfidencePage />}
            </PageTransition>
          </div>
        </main>
      </div>
      <MobileNav page={page} setPage={setPage} />
      <AIOrb />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
