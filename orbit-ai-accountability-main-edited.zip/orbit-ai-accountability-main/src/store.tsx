import { createContext, useContext, useState, type ReactNode } from 'react';

export type Priority = 'Low' | 'Medium' | 'High';
export type Recurrence = 'None' | 'Daily' | 'Weekly' | 'Monthly' | 'Yearly';
export type Importance = 'Critical' | 'Important' | 'Flexible' | 'Optional';
export type Risk = 'Low' | 'Medium' | 'High';

export interface Task {
  id: string;
  name: string;
  priority: Priority;
  duration: number;
  highFocus: boolean;
  recurring: Recurrence;
  category: string;
  importance: Importance;
  aiReschedule: boolean;
  done?: boolean;
}

export interface RankedTask {
  id: string;
  name: string;
  rank: number;
  probability: number;
  reason: string;
  icon: string;
  category: string;
  duration: number;
  focus: 'High' | 'Medium' | 'Low';
  energy: 'High' | 'Medium' | 'Low';
  why: string;
}

export interface TimelineEvent {
  id: string;
  time: string;
  label: string;
  reason: string;
  decision: string;
  result: string;
  kind: 'detect' | 'ask' | 'move' | 'predict';
}

export interface AIDecision {
  id: string;
  reason: string;
  decision: string;
  benefit: string;
  tone: 'info' | 'good' | 'warn';
  why: string;
  factors: { label: string; weight: number }[];
}

export interface RecurringTask {
  id: string;
  name: string;
  cadence: Recurrence;
  nextReminder: string;
  remainingDays: number;
  icon: string;
}

export interface BehaviourInsight {
  id: string;
  text: string;
  recommendation: string;
}

export interface Badge {
  id: string;
  label: string;
  icon: string;
  earned: boolean;
  color: string;
}

export interface Prediction {
  id: string;
  day: string;
  probability: number;
  headline: string;
  detail: string;
  recommendation: string;
  challenges: string;
}

export interface RealityFactor {
  id: string;
  label: string;
  impact: string;
  value: string;
}

interface Store {
  tasks: Task[];
  addTask: (t: Omit<Task, 'id'>) => void;
  toggleTask: (id: string) => void;
  successProbability: number;
  completion: number;
  consistency: number;
  procrastination: number;
  focusQuality: number;
  energyUtilization: number;
  weekly: number[];
  decisions: AIDecision[];
  recurring: RecurringTask[];
  behaviour: BehaviourInsight[];
  badges: Badge[];
  rankings: RankedTask[];
  timeline: TimelineEvent[];
  predictions: Prediction[];
  reality: {
    planned: number;
    achievable: number;
    factors: RealityFactor[];
    recommendation: string;
  };
  aiStatus: {
    monitoring: boolean;
    energy: number;
    stability: number;
    successProbability: number;
    distractionRisk: Risk;
  };
}

const initialTasks: Task[] = [
  { id: 't1', name: 'Study Statistics', priority: 'High', duration: 90, highFocus: true, recurring: 'Daily', category: 'Study', importance: 'Critical', aiReschedule: true, done: false },
  { id: 't2', name: 'Office Meeting', priority: 'High', duration: 60, highFocus: false, recurring: 'None', category: 'Office', importance: 'Important', aiReschedule: true, done: false },
  { id: 't3', name: 'Gym', priority: 'Medium', duration: 60, highFocus: false, recurring: 'Daily', category: 'Health', importance: 'Flexible', aiReschedule: true, done: true },
  { id: 't4', name: 'Medicine', priority: 'High', duration: 5, highFocus: false, recurring: 'Daily', category: 'Health', importance: 'Critical', aiReschedule: false, done: true },
  { id: 't5', name: 'Electricity Bill', priority: 'Medium', duration: 15, highFocus: false, recurring: 'Monthly', category: 'Finance', importance: 'Important', aiReschedule: true, done: false },
  { id: 't6', name: 'Prepare Presentation', priority: 'High', duration: 120, highFocus: true, recurring: 'None', category: 'Office', importance: 'Critical', aiReschedule: true, done: false },
];

const initialRankings: RankedTask[] = [
  {
    id: 'rk1', name: 'Statistics', rank: 1, probability: 97, reason: 'Your best productivity window is 9–11 AM.',
    icon: 'BookOpen', category: 'Study', duration: 90, focus: 'High', energy: 'High',
    why: 'Your focus has consistently been highest between 9–11 AM over the last three weeks. You complete study sessions 27% faster during this period. Scheduling it here increases your completion probability.',
  },
  {
    id: 'rk2', name: 'Office Meeting', rank: 2, probability: 91, reason: 'Scheduled during your peak collaboration window.',
    icon: 'Briefcase', category: 'Office', duration: 60, focus: 'Medium', energy: 'Medium',
    why: 'Your meeting effectiveness peaks between 2–4 PM when your social energy is highest. You contribute 34% more in afternoon meetings compared to mornings.',
  },
  {
    id: 'rk3', name: 'Electricity Bill', rank: 3, probability: 88, reason: 'Quick task, low effort, due within 3 days.',
    icon: 'Receipt', category: 'Finance', duration: 15, focus: 'Low', energy: 'Low',
    why: 'This takes under 15 minutes and you have never missed a bill within 3 days of the due date. Placing it between two heavier tasks creates a natural recovery break.',
  },
  {
    id: 'rk4', name: 'Gym', rank: 4, probability: 63, reason: 'Energy typically dips after 6 PM on weekdays.',
    icon: 'Dumbbell', category: 'Health', duration: 60, focus: 'Medium', energy: 'High',
    why: 'Your gym completion drops to 63% after 6 PM on weekdays. Moving it earlier or shortening the session on busy days keeps the streak alive without draining recovery.',
  },
];

const initialTimeline: TimelineEvent[] = [
  { id: 'tl1', time: '09:12', label: 'Meeting Extended', reason: 'Calendar detected a delay in your scheduled meeting.', decision: 'Asked whether the study session should continue.', result: 'User selected: Reschedule after meeting.', kind: 'detect' },
  { id: 'tl2', time: '09:13', label: 'Orbit Detected Delay', reason: 'Meeting running 45 min longer than your weekly average.', decision: 'Generated three alternative time slots for study.', result: 'Best slot identified: 7 PM.', kind: 'detect' },
  { id: 'tl3', time: '09:13', label: 'Asked User', reason: 'Your preference matters before any change.', decision: 'Would you still like to complete the delayed task?', result: 'User chose to reschedule.', kind: 'ask' },
  { id: 'tl4', time: '09:14', label: 'Study Moved to 7 PM', reason: 'Your second focus window opens at 7 PM with 84% completion rate.', decision: 'Study session relocated to evening slot.', result: 'Completion probability preserved at 91%.', kind: 'move' },
  { id: 'tl5', time: '09:15', label: 'Gym Reduced to 20 min', reason: 'Full session would push recovery too late after the moved study.', decision: 'Shortened gym to maintain streak without fatigue.', result: 'Health streak protected.', kind: 'move' },
  { id: 'tl6', time: '09:15', label: 'AI Success Prediction', reason: 'All adjustments factored into the model.', decision: 'Prediction recalculated with new schedule.', result: '91% — holding steady.', kind: 'predict' },
];

const initialDecisions: AIDecision[] = [
  {
    id: 'd1',
    reason: 'Your highest focus window is 9–11 AM based on 3 weeks of completion data.',
    decision: 'Statistics moved to 9:00 AM',
    benefit: 'Higher retention and faster completion',
    tone: 'good',
    why: 'Your focus has consistently been highest between 9–11 AM over the last three weeks. You complete study sessions 27% faster during this period. Scheduling it here increases your completion probability.',
    factors: [
      { label: 'Historical Behaviour', weight: 38 },
      { label: 'Energy', weight: 27 },
      { label: 'Calendar', weight: 18 },
      { label: 'Priority', weight: 12 },
      { label: 'Traffic', weight: 3 },
      { label: 'Weather', weight: 2 },
    ],
  },
  {
    id: 'd2',
    reason: "Today's office meeting is 45 min longer than your weekly average.",
    decision: 'Gym shortened to 20 minutes',
    benefit: 'Preserves energy without breaking the streak',
    tone: 'info',
    why: 'Your meeting is running 45 minutes longer than usual. A full gym session would push your recovery too late. A 20-minute session keeps the streak alive without draining your evening energy.',
    factors: [
      { label: 'Calendar', weight: 35 },
      { label: 'Energy', weight: 28 },
      { label: 'Historical Behaviour', weight: 18 },
      { label: 'Priority', weight: 10 },
      { label: 'Traffic', weight: 6 },
      { label: 'Weather', weight: 3 },
    ],
  },
  {
    id: 'd3',
    reason: 'You pay electricity bills 2–3 days after salary credit, consistently for 6 months.',
    decision: 'Electricity Bill scheduled after salary date',
    benefit: 'Avoids cash-flow stress and late penalties',
    tone: 'good',
    why: 'For the last 6 months you have paid this bill 2–3 days after salary credit. Scheduling it then avoids cash-flow stress and you have never missed the due date with this pattern.',
    factors: [
      { label: 'Historical Behaviour', weight: 52 },
      { label: 'Priority', weight: 22 },
      { label: 'Calendar', weight: 14 },
      { label: 'Energy', weight: 8 },
      { label: 'Traffic', weight: 2 },
      { label: 'Weather', weight: 2 },
    ],
  },
  {
    id: 'd4',
    reason: 'Heavy traffic predicted on your commute route between 5–7 PM.',
    decision: 'Study session shifted to evening',
    benefit: 'Recovers 40 min otherwise lost in traffic',
    tone: 'warn',
    why: 'Traffic on your route is 35% heavier than usual between 5–7 PM today. Moving study to 7 PM recovers the 40 minutes you would have lost in transit and keeps your focus window intact.',
    factors: [
      { label: 'Traffic', weight: 41 },
      { label: 'Energy', weight: 24 },
      { label: 'Calendar', weight: 16 },
      { label: 'Historical Behaviour', weight: 11 },
      { label: 'Priority', weight: 5 },
      { label: 'Weather', weight: 3 },
    ],
  },
];

const initialRecurring: RecurringTask[] = [
  { id: 'r1', name: 'Electricity Bill', cadence: 'Monthly', nextReminder: '28 Jul', remainingDays: 3, icon: 'Receipt' },
  { id: 'r2', name: 'Rent', cadence: 'Monthly', nextReminder: '1 Aug', remainingDays: 7, icon: 'Home' },
  { id: 'r3', name: 'FASTag Recharge', cadence: 'Monthly', nextReminder: '26 Jul', remainingDays: 1, icon: 'Car' },
  { id: 'r4', name: 'Medicine Refill', cadence: 'Monthly', nextReminder: '15 Aug', remainingDays: 21, icon: 'Pill' },
  { id: 'r5', name: 'Insurance Premium', cadence: 'Yearly', nextReminder: '12 Sep', remainingDays: 49, icon: 'Shield' },
];

const initialBehaviour: BehaviourInsight[] = [
  { id: 'b1', text: 'You usually study one day before exams.', recommendation: 'I will auto-block a 2-hour revision slot the day before every exam.' },
  { id: 'b2', text: 'You often postpone gym on Saturdays.', recommendation: 'Saturdays get a lighter 20-min home workout instead of the gym.' },
  { id: 'b3', text: 'Electricity bills are usually paid two days before the due date.', recommendation: 'Reminder moved 2 days earlier so you never miss the window.' },
  { id: 'b4', text: 'You complete office work fastest between 10–12 AM.', recommendation: 'Deep work tasks are prioritised in this window automatically.' },
];

const initialBadges: Badge[] = [
  { id: 'bd1', label: '7 Day Consistency', icon: 'Flame', earned: true, color: 'from-orange-400 to-amber-500' },
  { id: 'bd2', label: 'No Missed Tasks', icon: 'CheckCircle2', earned: true, color: 'from-emerald-400 to-teal-500' },
  { id: 'bd3', label: 'Early Bird', icon: 'Sunrise', earned: true, color: 'from-amber-400 to-orange-500' },
  { id: 'bd4', label: 'Deep Work Champion', icon: 'Brain', earned: true, color: 'from-blue-400 to-indigo-500' },
  { id: 'bd5', label: 'Time Master', icon: 'Clock', earned: false, color: 'from-slate-300 to-slate-400' },
  { id: 'bd6', label: '30 Day Streak', icon: 'Award', earned: false, color: 'from-slate-300 to-slate-400' },
];

const initialPredictions: Prediction[] = [
  {
    id: 'p1', day: 'Tomorrow', probability: 83, headline: 'Heavy workload predicted.',
    detail: 'Two meetings and a deadline cluster in the afternoon.', challenges: 'Back-to-back meetings reduce focus recovery time.',
    recommendation: 'I have already blocked a deep-work slot at 10 AM before the meeting storm.',
  },
  {
    id: 'p2', day: 'Friday', probability: 71, headline: 'Afternoon energy dip likely.',
    detail: 'Three meetings clustered between 2–5 PM reduce available focus time.', challenges: 'Your Friday focus drops 18% after 3 PM.',
    recommendation: 'Move light tasks to the morning to free up afternoon capacity.',
  },
  {
    id: 'p3', day: 'Saturday', probability: 58, headline: 'High chance of skipping Gym.',
    detail: 'You have skipped gym on 4 of the last 6 Saturdays.', challenges: 'You usually skip workouts after busy Fridays.',
    recommendation: 'Complete tomorrow\'s workout on Friday evening — your most consistent slot.',
  },
  {
    id: 'p4', day: 'Sunday', probability: 94, headline: 'Best day for long study sessions.',
    detail: 'Your Sunday focus sessions average 2.5 hours with 96% completion.', challenges: 'None detected — Sunday is your strongest day.',
    recommendation: 'I have reserved a 3-hour study block for you.',
  },
];

const initialReality = {
  planned: 10,
  achievable: 6,
  factors: [
    { id: 'f1', label: 'Current Energy', impact: 'Medium', value: '82%' },
    { id: 'f2', label: 'Traffic', impact: 'High', value: '+35%' },
    { id: 'f3', label: 'Meeting Duration', impact: 'High', value: '+45 min' },
    { id: 'f4', label: 'Weather', impact: 'Low', value: 'Clear' },
    { id: 'f5', label: 'Historical Behaviour', impact: 'Medium', value: '78% avg' },
  ],
  recommendation: "I've protected your highest-priority work and safely moved the remaining tasks. Your important work remains protected.",
};

const StoreContext = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [decisions] = useState<AIDecision[]>(initialDecisions);
  const [recurring] = useState<RecurringTask[]>(initialRecurring);
  const [behaviour] = useState<BehaviourInsight[]>(initialBehaviour);
  const [badges] = useState<Badge[]>(initialBadges);

  const addTask: Store['addTask'] = (t) => {
    setTasks((prev) => [{ ...t, id: `t${Date.now()}` }, ...prev]);
  };

  const toggleTask: Store['toggleTask'] = (id) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));

  const value: Store = {
    tasks,
    addTask,
    toggleTask,
    successProbability: 91,
    completion: 78,
    consistency: 82,
    procrastination: 18,
    focusQuality: 79,
    energyUtilization: 86,
    weekly: [62, 70, 68, 76, 80, 84, 91],
    decisions,
    recurring,
    behaviour,
    badges,
    rankings: initialRankings,
    timeline: initialTimeline,
    predictions: initialPredictions,
    reality: initialReality,
    aiStatus: {
      monitoring: true,
      energy: 82,
      stability: 74,
      successProbability: 91,
      distractionRisk: 'Low',
    },
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
