import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Clock, X, Sparkles, BookOpen, Calendar, ChevronRight, CheckCircle2, TrendingUp } from 'lucide-react';
import { PageHeader, AIThinking } from '@/components/ui';

type Stage = 'idle' | 'thinking1' | 'nudge1' | 'thinking2' | 'nudge2' | 'reschedule' | 'started' | 'rescheduled';

export default function AccountabilityPage() {
  const [stage, setStage] = useState<Stage>('idle');
  const [showDatePicker, setShowDatePicker] = useState(false);

  function go(next: Stage, think = true) {
    if (think) {
      setStage(next === 'nudge1' ? 'thinking1' : next === 'nudge2' ? 'thinking2' : next);
      const t = setTimeout(() => setStage(next), 1000);
      return () => clearTimeout(t);
    }
    setStage(next);
  }

  function reset() {
    setStage('idle');
    setShowDatePicker(false);
  }

  const thinking = stage === 'thinking1' || stage === 'thinking2';

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Accountability" subtitle="Orbit won't let a task quietly slip away." />

      <motion.div layout className="glass-strong overflow-hidden rounded-3xl">
        <div className="flex items-center gap-4 border-b border-white/50 bg-gradient-to-r from-blue-50/60 to-sky-50/60 p-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-100 text-blue-600">
            <BookOpen className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <div className="text-xs font-medium uppercase tracking-wider text-blue-500">Current Task</div>
            <div className="text-lg font-bold text-slate-800">Study Statistics</div>
            <div className="text-xs text-slate-500">90 min · High Focus · Scheduled 9:00 AM</div>
          </div>
        </div>

        <div className="p-5">
          <AnimatePresence mode="wait">
            {/* IDLE */}
            {stage === 'idle' && (
              <motion.div key="idle" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <p className="mb-4 text-sm text-slate-600">Ready to begin? Even 5 minutes builds momentum.</p>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setStage('started')}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.02]"
                  >
                    <Play className="h-4 w-4" /> Start Task
                  </button>
                  <button
                    onClick={() => go('nudge1')}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white/70"
                  >
                    <Clock className="h-4 w-4" /> Later
                  </button>
                </div>
              </motion.div>
            )}

            {/* THINKING 1 */}
            {stage === 'thinking1' && (
              <motion.div key="th1" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <AIThinking show lines={['Analyzing your previous behaviour...', 'Generating the best recommendation...']} />
              </motion.div>
            )}

            {/* NUDGE 1 */}
            {stage === 'nudge1' && (
              <motion.div key="n1" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <div className="mb-4 flex gap-3 rounded-2xl border border-blue-200 bg-blue-50/70 p-4">
                  <Sparkles className="h-5 w-5 shrink-0 text-blue-500" />
                  <p className="text-sm text-slate-700">
                    Last week you successfully completed similar study sessions after starting with only 10 minutes.
                    Would you like to begin with a <span className="font-semibold text-blue-700">15-minute focus sprint</span>?
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setStage('started')}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.02]"
                  >
                    <Play className="h-4 w-4" /> Start 15 Minutes
                  </button>
                  <button
                    onClick={() => go('nudge2')}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white/70"
                  >
                    Not Now
                  </button>
                </div>
              </motion.div>
            )}

            {/* THINKING 2 */}
            {stage === 'thinking2' && (
              <motion.div key="th2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <AIThinking show lines={['Analyzing your previous behaviour...', 'Generating the best recommendation...']} />
              </motion.div>
            )}

            {/* NUDGE 2 */}
            {stage === 'nudge2' && (
              <motion.div key="n2" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <div className="mb-4 flex gap-3 rounded-2xl border border-amber-200 bg-amber-50/70 p-4">
                  <Sparkles className="h-5 w-5 shrink-0 text-amber-500" />
                  <div className="space-y-1 text-sm text-slate-700">
                    <p>You postponed this task <span className="font-semibold text-amber-700">three times last week</span>.</p>
                    <p>Completing just 15 minutes today reduces tomorrow's workload.</p>
                    <p className="flex items-center gap-1.5 font-semibold text-emerald-700">
                      <TrendingUp className="h-4 w-4" /> Your Success Probability increases from 72% to 89%.
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setStage('started')}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.02]"
                  >
                    <Play className="h-4 w-4" /> Start Now
                  </button>
                  <button
                    onClick={() => setStage('reschedule')}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white/70"
                  >
                    Still Can't
                  </button>
                </div>
              </motion.div>
            )}

            {/* RESCHEDULE */}
            {stage === 'reschedule' && (
              <motion.div key="rs" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <div className="mb-4 flex gap-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
                  <Sparkles className="h-5 w-5 shrink-0 text-blue-500" />
                  <p className="text-sm text-slate-700">
                    No worries — rest is part of the plan. Would you like me to reschedule? I'll protect your streak by moving it, not dropping it.
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setStage('rescheduled')}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30"
                  >
                    Tomorrow <ChevronRight className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setShowDatePicker(true)}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white/70"
                  >
                    <Calendar className="h-4 w-4" /> Choose Date
                  </button>
                </div>
              </motion.div>
            )}

            {/* STARTED */}
            {stage === 'started' && (
              <motion.div key="st" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
                <div className="flex flex-col items-center py-6 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 18 }}
                    className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600"
                  >
                    <CheckCircle2 className="h-9 w-9" />
                  </motion.div>
                  <h3 className="text-lg font-bold text-slate-800">You're on it!</h3>
                  <p className="mt-1 text-sm text-slate-500">Orbit is tracking your session. Small starts beat perfect plans.</p>
                  <button onClick={reset} className="mt-4 text-sm font-medium text-blue-600 hover:underline">Back to task</button>
                </div>
              </motion.div>
            )}

            {/* RESCHEDULED */}
            {stage === 'rescheduled' && (
              <motion.div key="rd" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
                <div className="flex flex-col items-center py-6 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 18 }}
                    className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 text-blue-600"
                  >
                    <Calendar className="h-9 w-9" />
                  </motion.div>
                  <h3 className="text-lg font-bold text-slate-800">Moved to tomorrow</h3>
                  <p className="mt-1 text-sm text-slate-500">Rescheduled for 9:00 AM. Orbit will hold you to it.</p>
                  <button onClick={reset} className="mt-4 text-sm font-medium text-blue-600 hover:underline">Done</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!thinking && stage !== 'idle' && stage !== 'started' && stage !== 'rescheduled' && (
            <button onClick={reset} className="mt-4 inline-flex items-center gap-1 text-xs text-slate-400 hover:text-slate-600">
              <X className="h-3 w-3" /> Reset
            </button>
          )}
        </div>
      </motion.div>

      {/* Date picker modal */}
      <AnimatePresence>
        {showDatePicker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowDatePicker(false)}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong w-full max-w-sm rounded-3xl p-6"
            >
              <h3 className="mb-3 text-lg font-bold text-slate-800">Choose a date</h3>
              <input type="date" className="w-full rounded-xl border border-white/70 bg-white/70 px-4 py-3 text-slate-800 outline-none focus:border-blue-300" />
              <div className="mt-4 flex gap-3">
                <button
                  onClick={() => { setShowDatePicker(false); setStage('rescheduled'); }}
                  className="flex-1 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3 text-sm font-semibold text-white"
                >
                  Confirm
                </button>
                <button onClick={() => setShowDatePicker(false)} className="rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600">
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
