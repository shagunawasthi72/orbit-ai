import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Repeat, Check, Save, ArrowLeft, Clock, Flag, Zap, Sparkles, Bot } from 'lucide-react';
import { useStore, type Priority, type Recurrence, type Importance } from '@/store';
import { PageHeader } from '@/components/ui';
import { OptimizeOverlay } from '@/components/OptimizeOverlay';
import type { PageId } from '@/components/Nav';

const priorities: Priority[] = ['Low', 'Medium', 'High'];
const recurrences: Recurrence[] = ['None', 'Daily', 'Weekly', 'Monthly', 'Yearly'];
const categories = ['Study', 'Office', 'Personal', 'Health', 'Finance', 'Family'];
const importances: Importance[] = ['Critical', 'Important', 'Flexible', 'Optional'];

const importanceColor: Record<Importance, string> = {
  Critical: 'bg-rose-500 text-white shadow-rose-500/30',
  Important: 'bg-blue-500 text-white shadow-blue-500/30',
  Flexible: 'bg-emerald-500 text-white shadow-emerald-500/30',
  Optional: 'bg-slate-400 text-white shadow-slate-400/30',
};

export default function AddTaskPage({ setPage }: { setPage: (p: PageId) => void }) {
  const { addTask } = useStore();
  const [name, setName] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [duration, setDuration] = useState(45);
  const [highFocus, setHighFocus] = useState(false);
  const [recurring, setRecurring] = useState<Recurrence>('None');
  const [category, setCategory] = useState('Study');
  const [importance, setImportance] = useState<Importance>('Important');
  const [aiReschedule, setAiReschedule] = useState(true);
  const [saved, setSaved] = useState(false);
  const [optimizing, setOptimizing] = useState(false);

  const canSave = name.trim().length > 0;

  function handleSave() {
    if (!canSave) return;
    addTask({ name: name.trim(), priority, duration, highFocus, recurring, category, importance, aiReschedule });
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      setOptimizing(true);
    }, 800);
  }

  function handleOptimizeComplete() {
    setOptimizing(false);
    setName('');
    setPriority('Medium');
    setDuration(45);
    setHighFocus(false);
    setRecurring('None');
    setCategory('Study');
    setImportance('Important');
    setAiReschedule(true);
    setPage('scheduler');
  }

  return (
    <div className="mx-auto max-w-2xl">
      <button onClick={() => setPage('home')} className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800">
        <ArrowLeft className="h-4 w-4" /> Back
      </button>
      <PageHeader title="Plan My Day" subtitle="Tell Orbit what you want to accomplish. I'll decide the best time." />

      <div className="glass-strong rounded-3xl p-6 sm:p-8">
        <div className="space-y-6">
          {/* Name */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Task Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Study Statistics chapter 4"
              className="w-full rounded-xl border border-white/70 bg-white/70 px-4 py-3 text-slate-800 placeholder-slate-400 outline-none transition focus:border-blue-300 focus:bg-white"
            />
          </div>

          {/* Category */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Task Category</label>
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
                    category === c ? 'glass-blue' : 'glass-soft text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Priority */}
          <div>
            <label className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <Flag className="h-4 w-4" /> Priority
            </label>
            <div className="grid grid-cols-3 gap-2">
              {priorities.map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`rounded-xl py-2.5 text-sm font-semibold transition ${
                    priority === p
                      ? p === 'High'
                        ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                        : p === 'Medium'
                          ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/30'
                          : 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                      : 'glass-soft text-slate-600'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* AI Importance Score */}
          <div>
            <label className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <Sparkles className="h-4 w-4 text-blue-500" /> AI Importance Score
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {importances.map((imp) => (
                <button
                  key={imp}
                  onClick={() => setImportance(imp)}
                  className={`rounded-xl py-2.5 text-sm font-semibold transition ${
                    importance === imp ? `${importanceColor[imp]} shadow-lg` : 'glass-soft text-slate-600'
                  }`}
                >
                  {imp}
                </button>
              ))}
            </div>
          </div>

          {/* Duration */}
          <div>
            <label className="mb-2 flex items-center justify-between text-sm font-semibold text-slate-700">
              <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> Estimated Duration</span>
              <span className="text-blue-600">{duration} min</span>
            </label>
            <input type="range" min={5} max={240} step={5} value={duration} onChange={(e) => setDuration(Number(e.target.value))} className="w-full" />
            <div className="mt-1 flex justify-between text-[11px] text-slate-400">
              <span>5 min</span><span>4 hr</span>
            </div>
          </div>

          {/* High focus */}
          <button
            onClick={() => setHighFocus((v) => !v)}
            className="flex w-full items-center justify-between rounded-2xl border border-white/60 bg-white/50 p-4 text-left transition hover:bg-white/70"
          >
            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${highFocus ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>
                <Brain className="h-5 w-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-800">Requires High Focus</div>
                <div className="text-xs text-slate-500">Orbit will slot this during your peak hours</div>
              </div>
            </div>
            <div className={`relative h-7 w-12 rounded-full transition-colors ${highFocus ? 'bg-blue-600' : 'bg-slate-300'}`}>
              <motion.div layout className="absolute top-1 h-5 w-5 rounded-full bg-white shadow" style={{ left: highFocus ? 24 : 4 }} />
            </div>
          </button>

          {/* AI Reschedule */}
          <button
            onClick={() => setAiReschedule((v) => !v)}
            className="flex w-full items-center justify-between rounded-2xl border border-white/60 bg-white/50 p-4 text-left transition hover:bg-white/70"
          >
            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${aiReschedule ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-800">Can AI Automatically Reschedule?</div>
                <div className="text-xs text-slate-500">Let Orbit move this if something unexpected comes up</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-xs font-bold ${aiReschedule ? 'text-emerald-600' : 'text-slate-400'}`}>{aiReschedule ? 'YES' : 'NO'}</span>
              <div className={`relative h-7 w-12 rounded-full transition-colors ${aiReschedule ? 'bg-blue-600' : 'bg-slate-300'}`}>
                <motion.div layout className="absolute top-1 h-5 w-5 rounded-full bg-white shadow" style={{ left: aiReschedule ? 24 : 4 }} />
              </div>
            </div>
          </button>

          {/* Recurring */}
          <div>
            <label className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-slate-700">
              <Repeat className="h-4 w-4" /> Recurring Task
            </label>
            <div className="grid grid-cols-5 gap-2">
              {recurrences.map((r) => (
                <button
                  key={r}
                  onClick={() => setRecurring(r)}
                  className={`rounded-xl py-2 text-xs font-semibold transition sm:text-sm ${
                    recurring === r ? 'glass-blue' : 'glass-soft text-slate-600'
                  }`}
                >
                  {r === 'None' ? 'One-time' : r}
                </button>
              ))}
            </div>
            <AnimatePresence>
              {recurring !== 'None' && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-2 flex items-center gap-1.5 text-xs text-blue-600"
                >
                  <Zap className="h-3 w-3" /> Orbit will remember this as a {recurring.toLowerCase()} habit.
                </motion.p>
              )}
            </AnimatePresence>
          </div>

          {/* Optimize */}
          <div className="flex gap-3 pt-2">
            <button
              onClick={handleSave}
              disabled={!canSave}
              className="relative flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition disabled:cursor-not-allowed disabled:opacity-40"
            >
              <AnimatePresence mode="wait">
                {saved ? (
                  <motion.span key="saved" initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center gap-2">
                    <Check className="h-5 w-5" /> Saved!
                  </motion.span>
                ) : (
                  <motion.span key="save" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4" /> Optimize My Day
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
            <button onClick={() => setPage('home')} className="rounded-xl border border-white/60 bg-white/50 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white/70">
              Cancel
            </button>
          </div>
        </div>
      </div>

      <OptimizeOverlay show={optimizing} onComplete={handleOptimizeComplete} successProbability={91} />
    </div>
  );
}
