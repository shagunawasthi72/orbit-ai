import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sunrise, Sun, Sunset, Brain, Users, Moon, Zap, AlertTriangle, X, Sparkles, Clock, Activity, Car, Stethoscope, Home, GraduationCap, CloudRain, Bot } from 'lucide-react';
import { PageHeader, AIThinking, LiveDot } from '@/components/ui';
import { WhyButton } from '@/components/WhyPopover';

interface Block {
  id: string;
  time: string;
  name: string;
  icon: typeof Brain;
  tag: string;
  color: string;
}

const initialMorning: Block[] = [
  { id: 'm1', time: '7:00', name: 'Wake up & hydrate', icon: Sunrise, tag: 'Routine', color: 'bg-amber-100 text-amber-600' },
  { id: 'm2', time: '9:00', name: 'Study Statistics (Ch.4)', icon: Brain, tag: 'High Focus', color: 'bg-blue-100 text-blue-600' },
  { id: 'm3', time: '10:30', name: 'Prepare Presentation', icon: Brain, tag: 'High Focus', color: 'bg-blue-100 text-blue-600' },
];
const initialAfternoon: Block[] = [
  { id: 'a1', time: '12:30', name: 'Lunch & walk', icon: Sun, tag: 'Break', color: 'bg-emerald-100 text-emerald-600' },
  { id: 'a2', time: '14:00', name: 'Office Meeting', icon: Users, tag: 'Meeting', color: 'bg-violet-100 text-violet-600' },
  { id: 'a3', time: '15:30', name: 'Email & follow-ups', icon: Sun, tag: 'Low Focus', color: 'bg-slate-100 text-slate-600' },
];
const initialEvening: Block[] = [
  { id: 'e1', time: '18:00', name: 'Gym', icon: Moon, tag: 'Health', color: 'bg-emerald-100 text-emerald-600' },
  { id: 'e2', time: '19:30', name: 'Dinner with family', icon: Sunset, tag: 'Personal', color: 'bg-rose-100 text-rose-600' },
  { id: 'e3', time: '21:00', name: 'Read 10 pages', icon: Moon, tag: 'Low Focus', color: 'bg-slate-100 text-slate-600' },
];

const lifeEvents = [
  { id: 'traffic', label: 'Traffic', icon: Car, color: 'bg-amber-500' },
  { id: 'family', label: 'Family Emergency', icon: Home, color: 'bg-rose-500' },
  { id: 'power', label: 'Power Cut', icon: Zap, color: 'bg-slate-600' },
  { id: 'medical', label: 'Medical Emergency', icon: Stethoscope, color: 'bg-red-500' },
  { id: 'boss', label: 'Boss Called', icon: Users, color: 'bg-violet-500' },
  { id: 'rain', label: 'Heavy Rain', icon: CloudRain, color: 'bg-sky-500' },
  { id: 'class', label: 'Extra College Class', icon: GraduationCap, color: 'bg-indigo-500' },
  { id: 'guests', label: 'Guests Arrived', icon: Home, color: 'bg-teal-500' },
];

const explanations: Record<string, { decisions: string[]; reason: string; rate: number; why: string; factors: { label: string; weight: number }[] }> = {
  traffic: {
    decisions: ['Study moved to 7 PM', 'Gym shortened to 20 minutes', 'Commute buffer added'],
    reason: 'Traffic on your route is 35% heavier than usual. Moving deep work to the evening recovers the 40 minutes you would have lost in transit.',
    rate: 89,
    why: 'Traffic between 5–7 PM would waste 40 min. I moved study to 7 PM when your second focus window opens, and shortened gym so your streak stays alive without draining recovery.',
    factors: [{ label: 'Traffic', weight: 41 }, { label: 'Energy', weight: 24 }, { label: 'Calendar', weight: 16 }, { label: 'Historical Behaviour', weight: 11 }, { label: 'Priority', weight: 5 }, { label: 'Weather', weight: 3 }],
  },
  family: {
    decisions: ['Study moved to 7 PM', 'Emails postponed to tomorrow', 'Family time protected'],
    reason: 'Family comes first. I protected your evening so you can be fully present. Deep work shifts to your second focus window.',
    rate: 87,
    why: 'Family obligations take priority. Lighter tasks are deferred; deep work shifts to 7 PM where your completion rate is still 84%.',
    factors: [{ label: 'Priority', weight: 38 }, { label: 'Historical Behaviour', weight: 26 }, { label: 'Energy', weight: 18 }, { label: 'Calendar', weight: 12 }, { label: 'Traffic', weight: 4 }, { label: 'Weather', weight: 2 }],
  },
  power: {
    decisions: ['Device tasks moved to morning', 'Reading shifted to daylight', 'Gym kept as planned'],
    reason: 'Power-dependent work is prioritised in the morning grid. Low-power tasks fill the evening.',
    rate: 85,
    why: 'Power is usually restored within 2 hours. I front-loaded device tasks and kept analog tasks (reading, gym) for the outage window.',
    factors: [{ label: 'Calendar', weight: 32 }, { label: 'Historical Behaviour', weight: 28 }, { label: 'Energy', weight: 20 }, { label: 'Priority', weight: 12 }, { label: 'Traffic', weight: 5 }, { label: 'Weather', weight: 3 }],
  },
  medical: {
    decisions: ['All non-critical tasks paused', 'Medicine reminder kept', 'Study moved to tomorrow'],
    reason: 'Health comes first — always. Only critical reminders stay active; the rest rebuilds once you are ready.',
    rate: 80,
    why: 'Health comes first. I paused everything except your medicine reminder. Tomorrow morning I will auto-rebuild the day around how you feel.',
    factors: [{ label: 'Priority', weight: 52 }, { label: 'Historical Behaviour', weight: 20 }, { label: 'Energy', weight: 14 }, { label: 'Calendar', weight: 8 }, { label: 'Traffic', weight: 4 }, { label: 'Weather', weight: 2 }],
  },
  boss: {
    decisions: ['Emails moved to tomorrow', 'Study kept at 7 PM', 'Gym shortened to 20 min'],
    reason: 'Boss-called work takes priority over low-impact tasks. I protected your study session and trimmed gym.',
    rate: 86,
    why: 'Urgent work from your boss overrides low-impact tasks. I kept your critical study session and trimmed gym to preserve energy.',
    factors: [{ label: 'Priority', weight: 40 }, { label: 'Calendar', weight: 24 }, { label: 'Energy', weight: 18 }, { label: 'Historical Behaviour', weight: 10 }, { label: 'Traffic', weight: 5 }, { label: 'Weather', weight: 3 }],
  },
  rain: {
    decisions: ['Outdoor tasks moved indoors', 'Gym swapped for home workout', 'Commute buffer added'],
    reason: 'Rain increases commute time by ~20 min. Indoor alternatives keep the day intact.',
    rate: 90,
    why: 'Rain adds ~20 min to commutes. I swapped outdoor tasks for indoor equivalents and added a buffer so nothing cascades.',
    factors: [{ label: 'Weather', weight: 38 }, { label: 'Traffic', weight: 28 }, { label: 'Energy', weight: 16 }, { label: 'Calendar', weight: 10 }, { label: 'Historical Behaviour', weight: 5 }, { label: 'Priority', weight: 3 }],
  },
  class: {
    decisions: ['Study moved to 7 PM', 'Emails postponed', 'Class slot protected'],
    reason: 'College class is fixed. I moved flexible tasks around it and protected your study session in the evening.',
    rate: 88,
    why: 'Your class is a fixed block. I moved flexible tasks around it and kept study at 7 PM where your focus is still strong.',
    factors: [{ label: 'Calendar', weight: 42 }, { label: 'Energy', weight: 22 }, { label: 'Priority', weight: 18 }, { label: 'Historical Behaviour', weight: 10 }, { label: 'Traffic', weight: 5 }, { label: 'Weather', weight: 3 }],
  },
  guests: {
    decisions: ['Study moved to tomorrow', 'Gym swapped to morning', 'Evening protected for hosting'],
    reason: 'Hosting needs your full presence. I moved deep work to tomorrow and kept light morning tasks.',
    rate: 84,
    why: 'Guests need your attention tonight. I moved study to tomorrow morning (your highest completion slot) and kept gym early.',
    factors: [{ label: 'Priority', weight: 36 }, { label: 'Historical Behaviour', weight: 26 }, { label: 'Energy', weight: 18 }, { label: 'Calendar', weight: 12 }, { label: 'Traffic', weight: 5 }, { label: 'Weather', weight: 3 }],
  },
};

export default function SchedulerPage() {
  const [morning, setMorning] = useState(initialMorning);
  const [afternoon, setAfternoon] = useState(initialAfternoon);
  const [evening, setEvening] = useState(initialEvening);
  const [showModal, setShowModal] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [aiMsg, setAiMsg] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<{ event: string; decisions: string[]; reason: string; rate: number; why: string; factors: { label: string; weight: number }[] } | null>(null);
  const [askStage, setAskStage] = useState<{ event: string } | null>(null);

  function applyEvent(ev: (typeof lifeEvents)[number]) {
    setShowModal(false);
    // AI ALWAYS asks first before rescheduling
    setAskStage({ event: ev.id });
  }

  function confirmReschedule(keep: boolean) {
    if (!askStage) return;
    const ev = lifeEvents.find((e) => e.id === askStage.event)!;
    setAskStage(null);

    if (keep) {
      setAiMsg("Got it. I'll keep your task as-is. Your energy is better suited for this later today if anything changes.");
      return;
    }

    // Rebuild schedule
    setThinking(true);
    setAiMsg(null);
    setExplanation(null);
    setTimeout(() => {
      setMorning((prev) => [...prev, { id: `x${Date.now()}`, time: '11:15', name: `${ev.label} buffer`, icon: ev.icon, tag: 'Adjusted', color: 'bg-amber-100 text-amber-600' }]);
      setAfternoon((prev) => prev.slice(0, 2));
      setEvening((prev) => [...prev, { id: `y${Date.now()}`, time: '22:00', name: 'Rescheduled: Read 10 pages', icon: Moon, tag: 'Moved', color: 'bg-slate-100 text-slate-600' }]);
      setThinking(false);
      setAiMsg("Life changed. I adapted your schedule. Your important work remains protected.");
      const exp = explanations[ev.id];
      setExplanation({ event: ev.label, ...exp });
    }, 1800);
  }

  function Column({ title, icon: Icon, accent, energy, bestFor, blocks }: { title: string; icon: typeof Sunrise; accent: string; energy: number; bestFor: string[]; blocks: Block[] }) {
    return (
      <div className="glass-strong rounded-3xl p-5">
        <div className="mb-3 flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${accent}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-slate-800">{title}</h3>
            <p className="text-[11px] text-slate-500">{blocks.length} blocks</p>
          </div>
          <div className="text-right">
            <div className="text-xs font-semibold text-blue-600">Energy {energy}%</div>
          </div>
        </div>
        <div className="mb-3 flex flex-wrap gap-1">
          {bestFor.map((b) => (
            <span key={b} className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-medium text-blue-600">{b}</span>
          ))}
        </div>
        <div className="space-y-2.5">
          <AnimatePresence>
            {blocks.map((b) => (
              <motion.div
                key={b.id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: thinking ? 0.4 : 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ type: 'spring', stiffness: 300, damping: 26 }}
                className="flex items-center gap-3 rounded-2xl border border-white/60 bg-white/50 p-3"
              >
                <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${b.color}`}>
                  <b.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold text-slate-800">{b.name}</div>
                  <div className="text-[11px] text-slate-500">{b.tag}</div>
                </div>
                <span className="text-xs font-semibold text-slate-400">{b.time}</span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="AI Scheduler" subtitle="Your day, optimized around your natural energy." />

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-blue mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4"
      >
        <div className="flex items-center gap-2 text-sm font-medium">
          <Sparkles className="h-4 w-4" /> Optimized according to your energy profile.
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-white/20 px-4 py-2 text-sm font-semibold backdrop-blur transition hover:bg-white/30 active:scale-95"
        >
          <Sparkles className="h-4 w-4" /> Life Happens
        </button>
      </motion.div>

      <AnimatePresence>
        {thinking && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mb-6">
            <div className="glass-blue flex items-center gap-3 rounded-2xl p-4">
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.6, ease: 'linear' }} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/20">
                <Sparkles className="h-5 w-5 text-white" />
              </motion.div>
              <div>
                <div className="text-sm font-semibold">Life Happens. Don't worry. I'm rebuilding your day...</div>
                <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 2 }} className="text-xs text-white/80">
                  Finding the optimal arrangement...
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {aiMsg && !thinking && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mb-6 flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 text-sm font-medium text-emerald-700"
          >
            <Sparkles className="h-4 w-4" /> {aiMsg}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {explanation && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="glass-strong mb-6 rounded-3xl p-5"
          >
            <div className="mb-3 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400">
                <Brain className="h-4 w-4 text-white" />
              </div>
              <h3 className="text-base font-bold text-slate-800">AI Explanation</h3>
              <LiveDot />
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex gap-2"><span className="font-semibold text-slate-500">Unexpected Event:</span><span className="text-slate-800">{explanation.event}</span></div>
              <div className="rounded-xl bg-blue-50/60 p-3">
                <div className="mb-1 text-xs font-semibold text-blue-700">AI Decision</div>
                <ul className="space-y-1">
                  {explanation.decisions.map((d) => (
                    <li key={d} className="flex items-center gap-1.5 text-slate-700"><Sparkles className="h-3 w-3 text-blue-500" /> {d}</li>
                  ))}
                </ul>
              </div>
              <div className="flex gap-2"><span className="font-semibold text-slate-500">Reason:</span><span className="text-slate-700">{explanation.reason}</span></div>
              <div className="flex items-center justify-between rounded-xl bg-emerald-50/60 p-3">
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-emerald-600" />
                  <span className="font-semibold text-slate-700">Expected Completion Rate:</span>
                  <span className="text-lg font-bold text-emerald-600">{explanation.rate}%</span>
                </div>
                <WhyButton why={explanation.why} factors={explanation.factors} />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid gap-5 lg:grid-cols-3">
        <Column title="Morning · Deep Work" icon={Sunrise} accent="bg-amber-100 text-amber-600" energy={92} bestFor={['Deep Work', 'Coding', 'Study', 'Writing']} blocks={morning} />
        <Column title="Afternoon · Meetings" icon={Sun} accent="bg-violet-100 text-violet-600" energy={63} bestFor={['Meetings', 'Calls', 'Emails']} blocks={afternoon} />
        <Column title="Evening · Wind Down" icon={Sunset} accent="bg-indigo-100 text-indigo-600" energy={34} bestFor={['Exercise', 'Shopping', 'Reading', 'Household']} blocks={evening} />
      </div>

      {/* Life Happens Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowModal(false)}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong w-full max-w-md rounded-3xl p-6"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400">
                    <Sparkles className="h-4 w-4 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-800">Life Happens</h3>
                </div>
                <button onClick={() => setShowModal(false)} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <p className="mb-1 text-sm text-slate-500">Life rarely follows a perfect plan.</p>
              <p className="mb-4 text-sm font-medium text-slate-600">What happened?</p>
              <div className="grid grid-cols-2 gap-2">
                {lifeEvents.map((ev) => (
                  <button
                    key={ev.id}
                    onClick={() => applyEvent(ev)}
                    className="flex items-center gap-2 rounded-2xl border border-white/60 bg-white/60 p-3 text-left transition hover:bg-white active:scale-95"
                  >
                    <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${ev.color} text-white`}>
                      <ev.icon className="h-4 w-4" />
                    </div>
                    <span className="text-xs font-semibold text-slate-800">{ev.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Ask before reschedule modal */}
      <AnimatePresence>
        {askStage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="glass-strong w-full max-w-md rounded-3xl p-6"
            >
              <div className="mb-3 flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <h3 className="text-base font-bold text-slate-800">Orbit is asking</h3>
              </div>
              <p className="mb-4 text-sm text-slate-600">
                I've noticed today is much busier than usual. Don't worry — I've already found the best possible adjustment. Would you still like to complete the delayed task, or should I reschedule it for you?
              </p>
              <div className="flex gap-3">
                <button onClick={() => confirmReschedule(true)} className="flex-1 rounded-xl border border-white/60 bg-white/60 py-3 text-sm font-semibold text-slate-700 transition hover:bg-white">
                  Yes, keep it
                </button>
                <button onClick={() => confirmReschedule(false)} className="flex-1 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30">
                  Reschedule it
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
