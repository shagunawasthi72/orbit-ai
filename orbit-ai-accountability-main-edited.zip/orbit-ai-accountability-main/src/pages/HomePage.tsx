import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, Briefcase, Receipt, ChevronRight, Sparkles, TrendingUp, Clock,
  Activity, Zap, CalendarClock, Target, AlertTriangle, X, Brain, Sun, Sunrise, Car,
} from 'lucide-react';
import { useStore } from '@/store';
import { ConfidenceRing, LiveDot } from '@/components/ui';
import { LiveTimeline } from '@/components/LiveTimeline';
import { WhyButton } from '@/components/WhyPopover';
import type { PageId } from '@/components/Nav';

const rankIcon: Record<string, typeof BookOpen> = { BookOpen, Briefcase, Receipt, Dumbbell: BookOpen };

const riskBadge: Record<string, string> = {
  Low: 'bg-emerald-100 text-emerald-700',
  Medium: 'bg-amber-100 text-amber-700',
  High: 'bg-rose-100 text-rose-700',
};

const focusColor: Record<string, string> = {
  High: 'bg-blue-100 text-blue-700',
  Medium: 'bg-amber-100 text-amber-700',
  Low: 'bg-slate-100 text-slate-600',
};

const energyColor: Record<string, string> = {
  High: 'bg-violet-100 text-violet-700',
  Medium: 'bg-emerald-100 text-emerald-700',
  Low: 'bg-slate-100 text-slate-600',
};

const impactColor: Record<string, string> = {
  High: 'bg-rose-100 text-rose-600',
  Medium: 'bg-amber-100 text-amber-600',
  Low: 'bg-emerald-100 text-emerald-600',
};

const predictionFactors = ['Past Habits', 'Energy', 'Schedule', 'Task Priority', 'Consistency', 'Weather', 'Unexpected Events'];

export default function HomePage({ setPage }: { setPage: (p: PageId) => void }) {
  const { rankings, aiStatus, timeline, predictions, reality, successProbability } = useStore();
  const [briefing, setBriefing] = useState(false);
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : hour < 20 ? 'Good Evening' : 'Good Night';

  useEffect(() => {
    const seen = sessionStorage.getItem('orbit_briefing');
    if (!seen) {
      const t = setTimeout(() => setBriefing(true), 600);
      return () => clearTimeout(t);
    }
  }, []);

  function dismissBriefing() {
    setBriefing(false);
    sessionStorage.setItem('orbit_briefing', '1');
  }

  return (
    <div className="space-y-7">
      {/* Greeting */}
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-blue-600">{greeting}, Shagun 👋</p>
          <h1 className="text-3xl font-bold text-slate-800 sm:text-4xl">Orbit has already optimized your schedule.</h1>
          <p className="mt-1 text-sm text-slate-500">Because life doesn't always go according to plan.</p>
        </div>
        <button onClick={() => setPage('tasks')} className="glass-blue inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-transform hover:scale-[1.02]">
          <Sparkles className="h-4 w-4" /> Plan My Day
        </button>
      </motion.div>

      {/* AI Status Card */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="glass-strong rounded-3xl p-5">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400 shadow-lg shadow-blue-500/30">
            <Brain className="h-4 w-4 text-white" />
          </div>
          <h2 className="text-base font-bold text-slate-800">AI Status</h2>
          <span className="ml-1 text-[11px] text-slate-400">updated continuously</span>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <StatusTile icon={<LiveDot />} label="AI Monitoring" value="Active" tone="emerald" />
          <StatusTile icon={<Zap className="h-4 w-4 text-amber-500" />} label="Energy Level" value={`${aiStatus.energy}%`} tone="amber" />
          <StatusTile icon={<CalendarClock className="h-4 w-4 text-blue-500" />} label="Schedule Stability" value={`${aiStatus.stability}%`} tone="blue" />
          <StatusTile icon={<Target className="h-4 w-4 text-violet-500" />} label="Success Prediction" value={`${aiStatus.successProbability}%`} tone="violet" />
          <div className="flex flex-col justify-between rounded-2xl border border-white/60 bg-white/50 p-3">
            <span className="text-[11px] font-medium text-slate-500">Distraction Risk</span>
            <span className={`mt-1 inline-flex w-fit rounded-full px-2.5 py-1 text-xs font-semibold ${riskBadge[aiStatus.distractionRisk]}`}>{aiStatus.distractionRisk}</span>
          </div>
        </div>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* AI Success Prediction */}
        <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="glass-strong flex flex-col items-center justify-center rounded-3xl p-6 lg:col-span-1">
          <p className="mb-2 text-sm font-semibold uppercase tracking-wider text-slate-500">AI Success Prediction</p>
          <ConfidenceRing value={successProbability} label="Predicted" />
          <p className="mt-3 text-[11px] text-slate-400">Predicted using</p>
          <div className="mt-1.5 flex flex-wrap justify-center gap-1.5">
            {predictionFactors.map((f) => (<span key={f} className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-medium text-blue-600">{f}</span>))}
          </div>
          <div className="mt-4 flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-medium text-emerald-600">
            <TrendingUp className="h-4 w-4" /> +7% vs last week
          </div>
        </motion.div>

        {/* AI Priority Ranking */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="glass-strong rounded-3xl p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-800">AI Priority Ranking</h2>
            <span className="text-xs text-slate-500">ranked by completion probability</span>
          </div>
          <div className="space-y-3">
            {rankings.map((t, i) => {
              const Icon = rankIcon[t.icon] ?? BookOpen;
              const medal = t.rank === 1 ? '🥇' : t.rank === 2 ? '🥈' : t.rank === 3 ? '🥉' : '🏃';
              return (
                <motion.div key={t.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.12 + i * 0.06 }} className="group rounded-2xl border border-white/60 bg-white/50 p-3 transition-all hover:bg-white/70 hover:shadow-md">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{medal}</span>
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><Icon className="h-5 w-5" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold text-slate-800">{t.name}</div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500"><Clock className="h-3 w-3" /> {t.duration} min</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-600">{t.probability}%</div>
                      <div className="text-[10px] text-slate-400">completion</div>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${focusColor[t.focus]}`}>{t.focus} Focus</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${energyColor[t.energy]}`}>{t.energy} Energy</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <p className="text-[11px] text-slate-500"><span className="font-semibold text-slate-600">Reason:</span> {t.reason}</p>
                    <WhyButton why={t.why} />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Live AI Timeline */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="glass-strong rounded-3xl p-6">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-400"><Activity className="h-4 w-4 text-white" /></div>
          <h2 className="text-lg font-bold text-slate-800">Live AI Timeline</h2>
          <LiveDot />
        </div>
        <LiveTimeline events={timeline} />
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Reality Check */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }} className="glass-strong rounded-3xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-bold text-slate-800">Reality Check</h2>
          </div>
          <div className="mb-4 flex items-center justify-center gap-4 rounded-2xl bg-white/50 p-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-slate-400 line-through">{reality.planned}</div>
              <div className="text-[11px] text-slate-400">Today's Plan</div>
            </div>
            <ChevronRight className="h-6 w-6 text-blue-400" />
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{reality.achievable}</div>
              <div className="text-[11px] text-slate-500">Realistically Achievable</div>
            </div>
          </div>
          <div className="mb-3">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Orbit Analysis</div>
            <div className="space-y-1.5">
              {reality.factors.map((f) => (
                <div key={f.id} className="flex items-center justify-between rounded-lg bg-white/40 px-3 py-1.5">
                  <span className="text-xs text-slate-600">{f.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">{f.value}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${impactColor[f.impact]}`}>{f.impact}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="mb-4 rounded-2xl border border-blue-100 bg-blue-50/60 p-3">
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-blue-600">Orbit Recommendation</div>
            <p className="text-sm text-slate-700">{reality.recommendation}</p>
          </div>
          <button onClick={() => setPage('scheduler')} className="flex w-full items-center justify-center gap-1 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-2.5 text-sm font-semibold text-white transition hover:scale-[1.01]">
            View Optimized Schedule <ChevronRight className="h-4 w-4" />
          </button>
        </motion.div>

        {/* Looking Ahead */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-strong rounded-3xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-800">Looking Ahead</h2>
          </div>
          <div className="space-y-3">
            {predictions.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.22 + i * 0.06 }} className="rounded-2xl border border-white/60 bg-white/50 p-3 transition hover:shadow-md">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-800">{p.day}</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${p.probability >= 80 ? 'bg-emerald-100 text-emerald-700' : p.probability >= 65 ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'}`}>{p.probability}%</span>
                </div>
                <div className="mt-1 text-xs font-medium text-slate-600">{p.headline}</div>
                <div className="mt-0.5 text-[11px] text-slate-500">{p.detail}</div>
                <div className="mt-1.5 flex items-start gap-1.5 rounded-lg bg-amber-50/50 p-2 text-[11px] text-slate-600">
                  <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" /> {p.challenges}
                </div>
                <div className="mt-1.5 flex items-start gap-1.5 rounded-lg bg-blue-50/60 p-2 text-[11px] text-slate-600">
                  <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-blue-500" /> {p.recommendation}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Daily Briefing popup */}
      <AnimatePresence>
        {briefing && <DailyBriefing onClose={dismissBriefing} onView={() => { dismissBriefing(); setPage('scheduler'); }} />}
      </AnimatePresence>
    </div>
  );
}

function StatusTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone: string }) {
  const tones: Record<string, string> = { emerald: 'bg-emerald-50/70', amber: 'bg-amber-50/70', blue: 'bg-blue-50/70', violet: 'bg-violet-50/70' };
  return (
    <div className={`flex flex-col justify-between rounded-2xl border border-white/60 p-3 ${tones[tone]}`}>
      <div className="flex items-center gap-1.5">{icon}<span className="text-[11px] font-medium text-slate-500">{label}</span></div>
      <span className="mt-1 text-lg font-bold text-slate-800">{value}</span>
    </div>
  );
}

function DailyBriefing({ onClose, onView }: { onClose: () => void; onView: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.92, y: 24 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.92, y: 24 }} transition={{ type: 'spring', stiffness: 280, damping: 26 }} onClick={(e) => e.stopPropagation()} className="glass-strong w-full max-w-lg overflow-hidden rounded-3xl">
        <div className="relative bg-gradient-to-r from-blue-600 to-sky-500 p-6 text-white">
          <button onClick={onClose} className="absolute right-4 top-4 rounded-lg p-1 text-white/80 hover:bg-white/20"><X className="h-5 w-5" /></button>
          <div className="flex items-center gap-2"><Sunrise className="h-6 w-6" /><span className="text-xs font-semibold uppercase tracking-wider text-white/80">Orbit Daily Briefing</span></div>
          <h3 className="mt-2 text-2xl font-bold">Good Morning, Shagun 👋</h3>
          <p className="mt-1 text-sm text-white/85">I've already analyzed your day.</p>
        </div>
        <div className="space-y-3 p-6">
          <BriefLine icon={<Sun className="h-4 w-4 text-amber-500" />} text="Today's focus window: 9–11 AM." />
          <BriefLine icon={<Car className="h-4 w-4 text-amber-500" />} text="Traffic near your office is heavier than usual." />
          <BriefLine icon={<Briefcase className="h-4 w-4 text-violet-500" />} text="Meeting duration is expected to increase." />
          <BriefLine icon={<Sparkles className="h-4 w-4 text-blue-500" />} text="I've already optimized your schedule." />
          <div className="rounded-2xl border border-blue-200 bg-blue-50/70 p-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-blue-700"><Activity className="h-4 w-4" /> Today's AI Success Prediction: 91%</div>
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={onClose} className="flex-1 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/30 transition hover:scale-[1.02]">Start My Day</button>
            <button onClick={onView} className="rounded-xl border border-white/60 bg-white/60 px-5 py-3 text-sm font-medium text-slate-600 hover:bg-white">See Today's Plan</button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function BriefLine({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (<div className="flex items-start gap-2.5 rounded-xl bg-white/50 p-2.5"><span className="mt-0.5">{icon}</span><p className="text-sm text-slate-700">{text}</p></div>);
}
