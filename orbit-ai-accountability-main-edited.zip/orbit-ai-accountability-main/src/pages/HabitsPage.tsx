import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Repeat, Sparkles, Plus, Zap, Receipt, Home as HomeIcon, Car, Pill, Shield, Clock, Brain, Lightbulb } from 'lucide-react';
import { useStore, type Recurrence } from '@/store';
import { PageHeader, LiveDot } from '@/components/ui';

const iconMap: Record<string, typeof Repeat> = {
  Receipt,
  Home: HomeIcon,
  Car,
  Pill,
  Shield,
  Repeat,
};

const cadenceColor: Record<Recurrence, string> = {
  Monthly: 'bg-blue-100 text-blue-700',
  Weekly: 'bg-violet-100 text-violet-700',
  Yearly: 'bg-amber-100 text-amber-700',
  Daily: 'bg-emerald-100 text-emerald-700',
  None: 'bg-slate-100 text-slate-600',
};

export default function HabitsPage() {
  const { recurring, behaviour } = useStore();
  const [added, setAdded] = useState<Record<string, boolean>>({});

  function addRecurring(id: string) {
    setAdded((prev) => ({ ...prev, [id]: true }));
  }

  return (
    <div>
      <PageHeader title="Habit Memory" subtitle="What Orbit learned about your routines — and how it adapts." />

      {/* SECTION 1: Recurring Tasks */}
      <div className="mb-8">
        <div className="mb-4 flex items-center gap-2">
          <Repeat className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-800">Recurring Tasks</h2>
          <LiveDot />
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recurring.map((r, i) => {
            const Icon = iconMap[r.icon] ?? Repeat;
            const isAdded = added[r.id];
            const urgent = r.remainingDays <= 3;
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass-strong rounded-3xl p-5"
              >
                <div className="mb-3 flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-sky-400 text-white shadow-lg shadow-blue-500/30">
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <div className="text-base font-bold text-slate-800">{r.name}</div>
                    <span className={`mt-0.5 inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${cadenceColor[r.cadence]}`}>{r.cadence}</span>
                  </div>
                </div>

                <div className="mb-4 grid grid-cols-2 gap-2">
                  <div className="rounded-xl bg-white/50 p-2.5">
                    <div className="text-[10px] font-medium uppercase text-slate-400">Next Reminder</div>
                    <div className="text-sm font-bold text-slate-800">{r.nextReminder}</div>
                  </div>
                  <div className={`rounded-xl p-2.5 ${urgent ? 'bg-amber-50/70' : 'bg-white/50'}`}>
                    <div className="text-[10px] font-medium uppercase text-slate-400">Remaining</div>
                    <div className={`text-sm font-bold ${urgent ? 'text-amber-600' : 'text-slate-800'}`}>{r.remainingDays} days</div>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {isAdded ? (
                    <motion.div
                      key="done"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center justify-center gap-2 rounded-xl bg-emerald-50 py-2.5 text-sm font-semibold text-emerald-600"
                    >
                      <Zap className="h-4 w-4" /> Added as recurring
                    </motion.div>
                  ) : (
                    <motion.button
                      key="add"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => addRecurring(r.id)}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:scale-[1.02]"
                    >
                      <Plus className="h-4 w-4" /> Add as recurring
                    </motion.button>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: Behaviour Insights */}
      <div>
        <div className="mb-4 flex items-center gap-2">
          <Brain className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-800">Behaviour Insights</h2>
          <LiveDot color="bg-blue-400" />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {behaviour.map((b, i) => (
            <motion.div
              key={b.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="glass-strong rounded-3xl p-5"
            >
              <div className="mb-3 flex items-start gap-2">
                <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-blue-500" />
                <p className="text-sm font-medium text-slate-700">{b.text}</p>
              </div>
              <div className="rounded-2xl border border-blue-100 bg-blue-50/60 p-3">
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-blue-600">
                  <Lightbulb className="h-3.5 w-3.5" /> AI Recommendation
                </div>
                <p className="text-xs text-slate-700">{b.recommendation}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
