import { motion } from 'framer-motion';
import { CheckCircle2, Repeat, Clock, TrendingUp, Activity, Target, Zap, Flame, Sunrise, Brain, Award, Lock } from 'lucide-react';
import { useStore } from '@/store';
import { ConfidenceRing, PageHeader, StatChip } from '@/components/ui';
import type { LucideIcon } from 'lucide-react';

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const badgeIcons: Record<string, LucideIcon> = {
  Flame,
  CheckCircle2,
  Sunrise,
  Brain,
  Clock,
  Award,
};

export default function ConfidencePage() {
  const { successProbability, completion, consistency, procrastination, focusQuality, energyUtilization, weekly, badges } = useStore();

  return (
    <div>
      <PageHeader title="Success Analytics" subtitle="A clear picture of how Orbit predicts you'll do." />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Big ring */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-strong flex flex-col items-center rounded-3xl p-6"
        >
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-500">AI Success Prediction</h3>
          <ConfidenceRing value={successProbability} size={200} label="Predicted" />
          <div className="mt-4 flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-medium text-emerald-600">
            <TrendingUp className="h-4 w-4" /> +7% this week
          </div>
        </motion.div>

        {/* Stat chips */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="grid gap-4 sm:grid-cols-2 lg:col-span-2"
        >
          <StatChip icon={CheckCircle2} label="Task Completion Rate" value={`${completion}%`} color="bg-emerald-100 text-emerald-600" />
          <StatChip icon={Repeat} label="Consistency Score" value={`${consistency}%`} color="bg-blue-100 text-blue-600" />
          <StatChip icon={Clock} label="Procrastination Index" value={`${procrastination}%`} color="bg-amber-100 text-amber-600" />
          <StatChip icon={Target} label="Focus Quality" value={`${focusQuality}%`} color="bg-violet-100 text-violet-600" />
          <StatChip icon={Zap} label="Energy Utilization" value={`${energyUtilization}%`} color="bg-sky-100 text-sky-600" />
          <StatChip icon={Activity} label="Weekly Improvement" value="+7%" color="bg-emerald-100 text-emerald-600" />

          {/* Weekly bar chart */}
          <div className="glass-strong rounded-3xl p-5 sm:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800">Weekly Improvement</h3>
              <span className="text-xs text-slate-500">Success Probability %</span>
            </div>
            <div className="flex h-44 items-end justify-between gap-2">
              {weekly.map((v, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-2">
                  <div className="flex h-36 w-full items-end justify-center">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${v}%` }}
                      transition={{ delay: 0.1 + i * 0.07, duration: 0.7, ease: 'easeOut' }}
                      className="w-full max-w-[28px] rounded-t-lg bg-gradient-to-t from-blue-600 to-sky-300"
                      style={{ minHeight: 8 }}
                    />
                  </div>
                  <span className="text-[11px] font-medium text-slate-500">{days[i]}</span>
                  <span className="text-[10px] text-slate-400">{v}%</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Completion breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-strong rounded-3xl p-6"
        >
          <h3 className="mb-4 text-sm font-bold text-slate-800">Completion Breakdown</h3>
          <div className="space-y-3">
            {[
              { label: 'Completed on time', value: 62, color: 'bg-emerald-500' },
              { label: 'Completed late', value: 16, color: 'bg-amber-500' },
              { label: 'Postponed', value: 14, color: 'bg-blue-400' },
              { label: 'Missed', value: 8, color: 'bg-rose-400' },
            ].map((row, i) => (
              <div key={row.label}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-slate-600">{row.label}</span>
                  <span className="font-semibold text-slate-700">{row.value}%</span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${row.value}%` }}
                    transition={{ delay: 0.2 + i * 0.08, duration: 0.8, ease: 'easeOut' }}
                    className={`h-full rounded-full ${row.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Trend line */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass-strong rounded-3xl p-6"
        >
          <h3 className="mb-4 text-sm font-bold text-slate-800">4-Week Trend</h3>
          <div className="relative h-44 w-full">
            <svg viewBox="0 0 300 140" className="h-full w-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="lineFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgba(37,99,235,0.35)" />
                  <stop offset="100%" stopColor="rgba(37,99,235,0)" />
                </linearGradient>
              </defs>
              <motion.path
                d="M0,100 C40,90 60,70 100,72 C140,74 160,50 200,46 C240,42 260,30 300,24"
                fill="none"
                stroke="#2563eb"
                strokeWidth="3"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.4, ease: 'easeOut' }}
              />
              <motion.path
                d="M0,100 C40,90 60,70 100,72 C140,74 160,50 200,46 C240,42 260,30 300,24 L300,140 L0,140 Z"
                fill="url(#lineFill)"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.8 }}
              />
              {[[0, 100], [100, 72], [200, 46], [300, 24]].map(([x, y], i) => (
                <motion.circle
                  key={i}
                  cx={x}
                  cy={y}
                  r="4"
                  fill="#fff"
                  stroke="#2563eb"
                  strokeWidth="2.5"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.8 + i * 0.12 }}
                />
              ))}
            </svg>
            <div className="mt-2 flex justify-between text-[11px] text-slate-400">
              {['Week 1', 'Week 2', 'Week 3', 'Week 4'].map((w) => (
                <span key={w}>{w}</span>
              ))}
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <Activity className="h-4 w-4 text-blue-500" /> Success Probability climbing steadily — keep the rhythm.
          </div>
        </motion.div>
      </div>

      {/* Achievement Badges */}
      <div className="mt-6">
        <div className="mb-4 flex items-center gap-2">
          <Award className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-800">Achievement Badges</h2>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {badges.map((b, i) => {
            const Icon = b.earned ? (badgeIcons[b.icon] ?? Award) : Lock;
            return (
              <motion.div
                key={b.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06 }}
                className={`flex flex-col items-center rounded-3xl p-4 text-center ${b.earned ? 'glass-strong' : 'glass-soft opacity-60'}`}
              >
                <div className={`mb-2 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${b.color} text-white shadow-lg`}>
                  <Icon className="h-7 w-7" />
                </div>
                <div className={`text-xs font-semibold ${b.earned ? 'text-slate-700' : 'text-slate-400'}`}>{b.label}</div>
                <div className="mt-0.5 text-[10px] text-slate-400">{b.earned ? 'Earned' : 'Locked'}</div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
